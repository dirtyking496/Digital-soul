import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { VRMLoaderPlugin, VRMUtils, VRMExpressionPresetName } from "@pixiv/three-vrm";

const canvas = document.querySelector("#world3d");
const status = document.querySelector("#worldStatus");
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101a2b);
scene.fog = new THREE.Fog(0x101a2b, 12, 35);
const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
camera.position.set(0, 2.3, 7);
const renderer = new THREE.WebGLRenderer({canvas, antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;

scene.add(new THREE.HemisphereLight(0xbdd7ff, 0x263522, 2.0));
const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(4, 8, 5); scene.add(sun);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(40,40), new THREE.MeshStandardMaterial({color:0x315342, roughness:1}));
floor.rotation.x = -Math.PI/2; floor.position.y = -0.03; scene.add(floor);
const grid = new THREE.GridHelper(40,40,0x496b61,0x3a594e); grid.position.y = 0; scene.add(grid);

// Simple stylized placeholder until the user loads a rigged VRM avatar.
const placeholder = new THREE.Group();
const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.38,0.95,6,12), new THREE.MeshStandardMaterial({color:0x796cff, roughness:.8}));
body.position.y = 1.05; placeholder.add(body);
const head = new THREE.Mesh(new THREE.SphereGeometry(.32,24,18), new THREE.MeshStandardMaterial({color:0xd7a982, roughness:.8}));
head.position.y = 1.88; placeholder.add(head);
const eyes = new THREE.Mesh(new THREE.BoxGeometry(.16,.035,.025), new THREE.MeshBasicMaterial({color:0x172033}));
eyes.position.set(0,1.91,.29); placeholder.add(eyes);
scene.add(placeholder);

let currentVRM = null;
let activeRoot = placeholder;
let roaming = false;
let destination = new THREE.Vector3(0,0,0);
let nextDecision = 0;
let audioContext = null, analyser = null, audioSource = null, lipActive = false;
const clock = new THREE.Clock();

function resize(){
  const w = canvas.clientWidth || 640, h = canvas.clientHeight || 360;
  renderer.setSize(w,h,false); camera.aspect=w/h; camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(canvas); resize();

function chooseDestination(){
  destination.set((Math.random()-.5)*9,0,(Math.random()-.5)*7);
  nextDecision = performance.now() + 2500 + Math.random()*5000;
}
chooseDestination();

document.querySelector("#wander").addEventListener("click",()=>{
  roaming=true; chooseDestination();
  status.textContent="Vie autonome activée : le personnage choisit des destinations et se promène dans la scène.";
});
document.querySelector("#stopWander").addEventListener("click",()=>{
  roaming=false; status.textContent="Déplacements autonomes en pause.";
});

document.querySelector("#vrmFile").addEventListener("change", async (event)=>{
  const file=event.target.files?.[0]; if(!file) return;
  if(!file.name.toLowerCase().endsWith(".vrm")) {
    status.textContent="Choisis un fichier .vrm (avatar 3D riggé). Une image PNG/JPG ne peut pas être animée comme un avatar.";
    return;
  }
  status.textContent="Chargement de l’avatar VRM…";
  try {
    const url=URL.createObjectURL(file);
    const loader=new GLTFLoader();
    loader.register(parser=>new VRMLoaderPlugin(parser));
    const gltf=await loader.loadAsync(url);
    const vrm=gltf.userData.vrm;
    if(!vrm) throw new Error("Ce fichier ne contient pas de personnage VRM compatible.");
    VRMUtils.removeUnnecessaryVertices(gltf.scene);
    VRMUtils.removeUnnecessaryJoints(gltf.scene);
    if(currentVRM) scene.remove(currentVRM.scene);
    scene.remove(placeholder);
    currentVRM=vrm;
    activeRoot=vrm.scene;
    activeRoot.position.set(0,0,0);
    scene.add(activeRoot);
    status.textContent="Avatar VRM chargé. Les déplacements autonomes et l’animation de bouche peuvent maintenant agir sur son rig.";
    URL.revokeObjectURL(url);
  } catch(err) {
    console.error(err);
    status.textContent="Impossible de charger cet avatar : "+err.message;
  }
});

document.querySelector("#lipSync").addEventListener("click", async ()=>{
  const audio=document.querySelector("#generatedAudio");
  if(!audio) {
    status.textContent="Génère d’abord une voix avec le bouton « Générer la voix », puis lance la lecture.";
    return;
  }
  try {
    if(!audioContext) audioContext=new AudioContext();
    await audioContext.resume();
    if(!audioSource) {
      audio.crossOrigin="anonymous";
      audioSource=audioContext.createMediaElementSource(audio);
      analyser=audioContext.createAnalyser();
      analyser.fftSize=256;
      audioSource.connect(analyser);
      analyser.connect(audioContext.destination);
    }
    lipActive=true;
    await audio.play();
    status.textContent="Synchronisation labiale active : la bouche suit l’intensité sonore. Le modèle doit avoir une expression VRM « Aa » pour afficher le mouvement.";
  } catch(err) {
    status.textContent="Audio non accessible pour l’analyse (CORS ou lecture bloquée). Essaie avec un fichier audio local ou un hébergement autorisant CORS.";
  }
});

const data=new Uint8Array(128);
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.05);
  if(roaming && performance.now()>nextDecision) chooseDestination();
  if(roaming){
    const p=activeRoot.position;
    const dx=destination.x-p.x, dz=destination.z-p.z;
    const dist=Math.hypot(dx,dz);
    if(dist>.12){
      const speed=1.05*dt;
      p.x += dx/dist*speed; p.z += dz/dist*speed;
      activeRoot.rotation.y=Math.atan2(dx,dz);
    } else chooseDestination();
  }
  if(currentVRM){
    currentVRM.update(dt);
    if(lipActive && analyser){
      analyser.getByteFrequencyData(data);
      let sum=0; for(let i=0;i<data.length;i++) sum+=data[i];
      const level=(sum/data.length)/255;
      const mouth=Math.min(.9,Math.max(0,(level-.035)*2.8));
      currentVRM.expressionManager?.setValue(VRMExpressionPresetName.Aa,mouth);
      if(document.querySelector("#generatedAudio")?.ended){
        currentVRM.expressionManager?.setValue(VRMExpressionPresetName.Aa,0);
        lipActive=false;
      }
    }
  } else if(lipActive && analyser) {
    // The placeholder has no facial rig; the status still demonstrates audio analysis is running.
    analyser.getByteFrequencyData(data);
  }
  renderer.render(scene,camera);
}
animate();
